package com.company.model.amc;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="packagevariant")
public class ServicePackageVariant extends PackageVariant {

}